package org.company;

import org.company.exporters.ExporterProvider;
import org.company.lang.Dictionary;
import org.company.lang.SentenceRecognizer;
import org.company.parser.SentenceParser;
import org.company.parser.WordsExtractor;
import org.junit.Before;
import org.junit.Test;
import org.xmlunit.builder.Input;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import static org.company.parser.OutputFormat.CSV;
import static org.company.parser.OutputFormat.XML;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.xmlunit.matchers.CompareMatcher.isIdenticalTo;

public class SentenceParserTest {

    private SentenceParser parser;

    @Before
    public void setUp() {
        Dictionary dict = new Dictionary();
        dict.init();
        ExporterProvider exporter = new ExporterProvider();
        exporter.bootstrap();
        parser = new SentenceParser(dict, exporter, new SentenceRecognizer(), new WordsExtractor());
    }
    /**
     * In these Resources we are storing the files for test purposes and responses-
     * are also stored in these defind path.
     * Change it as per your requirement?
     */

    @Test
    public void shouldParseTextToXml() throws FileNotFoundException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        parser.parse(new FileInputStream(Paths.get("src\\test\\files\\small.in").toFile()), baos, XML);

        assertThat(Input.fromString(new String(baos.toByteArray(), StandardCharsets.UTF_8)),
                isIdenticalTo(Input.fromFile("src\\test\\files\\small.xml")));
    }

/**
 * In these Resources we are storing the files for test purposes and responses-
 * are also stored in these defind path.
 * Change it as per your requirement?
 */

    @Test
    public void shouldParseTextToCsv() throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        parser.parse(new FileInputStream(Paths.get("src\\test\\files\\small.in").toFile()), baos, CSV);
        String expect = new String(Files.readAllBytes(Paths.get("src\\test\\files\\small.csv")));
        String result = new String(baos.toByteArray(), StandardCharsets.UTF_8);
        assertEquals(expect, result);
    }
}