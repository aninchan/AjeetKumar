package org.company;

import com.google.inject.Guice;
import com.google.inject.Injector;
import org.company.exporters.ExporterProvider;
import org.company.parser.OutputFormat;
import org.company.parser.SentenceParser;
import javax.inject.Inject;
import javax.xml.stream.XMLStreamException;
import java.io.*;

/**
 * Hello world!
 *
 */
public class Application{

    @Inject
    private ExporterProvider provider;

    @Inject
    private SentenceParser parser;

    public static void main(String[] args) throws IOException, XMLStreamException {
        if(args.length == 0) {
            System.err.println("Please provide the desired output format (xml|csv)");
            System.exit(0);
        }

        OutputFormat format = OutputFormat.XML;
        try {
            format = OutputFormat.valueOf(args[0].toUpperCase());
        } catch(IllegalArgumentException ex) {
            System.err.println("Please provide valid output format (xml|csv)");
            System.exit(0);
        }

        Injector injector = Guice.createInjector(new MyModule());
        Application main = injector.getInstance(Application.class);

        main.run(format,args[1],args[2],args[0]);
    }

    void run(OutputFormat format, String inputpath, String outputpath,String extension) throws FileNotFoundException {
        provider.bootstrap();
        InputStream input=new FileInputStream(inputpath);
        OutputStream output=new FileOutputStream(new StringBuilder().append(outputpath).append(".").append(extension.toLowerCase()).toString());
        parser.parse(input, output, format);
    }

}
